
#[cfg(test)]
mod store_study {
    extern crate std;
    use self::std::{hint::black_box,println,time::Instant};
    use crate::address::{Adrs,WOTS_HASH,WOTS_PRF};
    use crate::hash::{short_block,chain_blocks_portable};
    fn run<const N: usize,const L: usize>() {
        let state=core::array::from_fn(|i| 0xf1e2d3c4u32.wrapping_mul(i as u32+1));
        let sk:[u8;N]=core::array::from_fn(|i| (i*17+5) as u8);
        let ad=Adrs::new().with_layer(4).with_tree(0x1032047809ab).with_type(WOTS_HASH).with_keypair(0x2304);
        let len=2*N+3;
        for nkeys in [0usize,1,2,3,7,8,9,15,16] {
            let first=0xfffa_u32;
            let mut out=[[0x5a;L];17];let mut expect=out;
            for k in 0..nkeys { for i in 0..len {
                let base=ad.with_type(WOTS_PRF).with_keypair(first+k as u32).with_word2(i as u32);
                let seed=crate::sha256::digest(&crate::sha256::compress_portable(&state,&short_block(&base,&sk),0));
                let addr=ad.with_type(WOTS_HASH).with_keypair(first+k as u32).with_word2(i as u32);
                let mut block=[short_block(&addr,&seed[..N])];
                chain_blocks_portable::<N>(&state,&mut block,&[0],&[15]);
                expect[k][22+i*N..22+(i+1)*N].copy_from_slice(&block[0][22..22+N]);
            }}
            super::wots_endpoints(&state,&sk,ad,first,&mut out[..nkeys]);
            assert_eq!(expect,out);
            let t=Instant::now();
            for _ in 0..16 {super::wots_endpoints(black_box(&state),&sk,ad,first,black_box(&mut out[..nkeys]));}
            println!("K,endpoints,{N},{nkeys},{}",t.elapsed().as_nanos()/16);
        }
        let sig:[u8;32*67]=core::array::from_fn(|i|(i*19+37) as u8);
        for shape in 0..10 {
            let digits:[u32;67]=core::array::from_fn(|i| match shape {0=>0,1=>15,2=>14,3=>if i%16==0{0}else{15},4=>if i%2==0{15}else{0},5=>(i%16) as u32,_=>((17*i+i/5+7*shape)%16) as u32});
            let mut out=[[0xa5;64];70]; let mut expected=out;
            for i in 0..len {
                let mut block=[short_block(&ad.with_word2(i as u32),&sig[i*N..(i+1)*N])];
                chain_blocks_portable::<N>(&state,&mut block,&[digits[i]],&[15]);
                expected[i][22..22+N].copy_from_slice(&block[0][22..22+N]);
            }
            super::recover::<N>(&state,ad,&sig,&digits[..len],&mut out);
            assert_eq!(expected,out);
            let t=Instant::now();
            for _ in 0..256 {super::recover::<N>(black_box(&state),ad,&sig,&digits[..len],black_box(&mut out));}
            println!("K,recover,{N},{shape},{}",t.elapsed().as_nanos()/256);
        }
    }
    #[test] fn measure_wots(){run::<16,640>();run::<24,1280>();run::<32,2304>();}
}
