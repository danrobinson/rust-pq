
#[cfg(test)]
mod store_study {
    extern crate std;
    use self::std::{hint::black_box, time::Instant, println};
    fn run<const N:usize>(len:usize,shape:usize) {
        let init:[u32;8]=core::array::from_fn(|i| 1234567*i as u32);
        let before:[[u8;64];33]=core::array::from_fn(|i| core::array::from_fn(|k| (3+17*i+91*k) as u8));
        let start:[u32;33]=core::array::from_fn(|i| 0xffff0000+37*i as u32);
        let end:[u32;33]=core::array::from_fn(|i|start[i]+match shape {
            0=>15,1=>(i%16) as u32,2=>if i%4==0 {1}else{0},_=>0 });
        let mut test=before; let mut reference=before;
        crate::hash::chain_blocks_portable::<N>(&init,&mut reference[..len],&start,&end);
        unsafe { super::avx512::chains::<N>(&init,&mut test[..len],&start,&end) };
        assert_eq!(test,reference);
        let t=Instant::now();
        for _ in 0..384 {unsafe {super::avx512::chains::<N>(black_box(&init),black_box(&mut test[..len]),&start,&end)};}
        println!("K,chains,{shape},{N},{len},{}",t.elapsed().as_nanos()/384);
    }
    #[test] fn measure_chains(){
        for len in [0,1,7,8,9,15,16,17,24,31,32,33] { for shape in 0..4 {
            run::<16>(len,shape);run::<24>(len,shape);run::<32>(len,shape);
        } }
    }
}