#[cfg(test)]
mod wide_raw {
    extern crate std;
    use super::*;
    use core::hint::black_box;

    #[target_feature(enable="avx2")]
    fn measure() -> f64 {
        let seeds: [[u32; 8]; 8] = core::array::from_fn(|i|
            core::array::from_fn(|l| (l*37+i*11+5) as u32));
        let words: [[u32; 8]; 16] = core::array::from_fn(|i|
            core::array::from_fn(|l| (l*11+i*7+3) as u32));
        let inputs = words.map(|x| unsafe { _mm256_loadu_si256(x.as_ptr().cast()) });
        let mut state = seeds.map(|x| unsafe { _mm256_loadu_si256(x.as_ptr().cast()) });
        let run = |initial: [__m256i;8]| {
            let words = *black_box(&inputs);
            compress_words(initial, words)
        };
        let first = run(state);
        for lane in 0..8 {
            let mut bytes = [0u8; 64];
            for i in 0..16 {
                bytes[i*4..(i+1)*4].copy_from_slice(&words[i][lane].to_be_bytes());
            }
            let expected = crate::sha256::compress_portable(
                &core::array::from_fn(|i| seeds[i][lane]), &bytes, 0);
            for i in 0..8 {
                let lanes: [u32; 8] = unsafe { core::mem::transmute(first[i]) };
                assert_eq!(lanes[lane], expected[i]);
            }
        }
        let count = 1usize << 20;
        let start = std::time::Instant::now();
        for _ in 0..count/8 {
            state = run(state);
        }
        black_box(state);
        start.elapsed().as_nanos() as f64 / count as f64
    }

    #[test]
    #[ignore]
    fn raw_sha256() {
        assert!(std::is_x86_feature_detected!("avx2"));
        std::println!("WIDE_RAW,rust256_8,{:.6}", unsafe { measure() });
    }
}
