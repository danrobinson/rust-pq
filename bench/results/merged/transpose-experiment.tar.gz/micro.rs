
#[cfg(test)]
mod store_study {
    extern crate std;
    use self::std::{hint::black_box, time::Instant,println};
    use super::{fors_leaves, fors_parents, key_digests};
    use crate::{address::{Adrs,FORS_TREE,FORS_PRF},hash::{trunc,pair_block,short_block},sha256::compress_portable};
    const STATE:[u32;8]=[11, 37, 65535, 888,0x98765432,0xdeadbeef,0,278];
    fn bench(f:impl FnMut(), op:&str,n:usize,b:usize) {
        let t=Instant::now();
        (0..2048).for_each({let mut f=f;move |_| f()});
        println!("K,{op},{n},{b},{}",t.elapsed().as_nanos()/2048);
    }
    fn leaves<const N:usize>(b:usize) {
        let a=Adrs::new().with_tree(89).with_type(FORS_TREE).with_keypair(23);
        let mut out=[[0x8d;N];33]; let sk=[0x52;N]; let first=98761;
        fors_leaves(&STATE,&sk,a,first,&mut out[..b]);
        let mut want=[[0x8d;N];33];
        for (j,v) in want[..b].iter_mut().enumerate(){
            let idx=first+j as u32;
            let p=short_block(&a.with_type(FORS_PRF).with_keypair(23).with_word3(idx),&sk);
            let d=trunc::<N>(&compress_portable(&STATE,&p,0));
            *v=trunc(&compress_portable(&STATE,&short_block(&a.with_word3(idx),&d),0));
        }
        assert_eq!(out,want);
        bench(||fors_leaves(black_box(&STATE),&sk,a,first,black_box(&mut out[..b])),"leaves",N,b);
    }
    #[test] fn measure_stores(){
        let a=Adrs::new().with_type(FORS_TREE).with_word2(4);
        for b in (1..=16).chain([17,23,31,32]) {
            leaves::<16>(b); leaves::<24>(b); leaves::<32>(b);
            if b>=2{
                let mut rows:[[u8;16];64]=core::array::from_fn(|i|core::array::from_fn(|j|(i*35+j*11) as u8));
                let mut want=rows;
                for j in 0..b{
                    want[j]=trunc(&compress_portable(&STATE,&pair_block(&a.with_word3(768+j as u32),&rows[2*j],&rows[2*j+1]),0));
                }
                fors_parents(&STATE,a,768,&mut rows,b); assert_eq!(rows,want);
                bench(||{black_box(fors_parents(&STATE,a,768,black_box(&mut rows),b));},"parents",16,b);
            }
            if b<=16{
                let rows:[[u8;640];16]=core::array::from_fn(|i|core::array::from_fn(|j|(i*19+j*41) as u8));
                let mut out=[[0x8d;16];16];
                let mut want=out;
                for j in 0..b{
                    let s=(0..640).step_by(64).fold(STATE,|s,k|compress_portable(&s,&rows[j],k));
                    want[j]=trunc(&s);
                }
                key_digests(&STATE,&rows[..b],&mut out[..b]);assert_eq!(out,want);
                bench(||key_digests(&STATE,black_box(&rows[..b]),black_box(&mut out[..b])),"digest",16,b);
            }
        }
    }
}
