
#[cfg(test)]
mod store_study {
    extern crate std;
    use self::std::{hint::black_box, time::Instant,println};
    use super::{fors_leaves};
    use crate::{address::{Adrs,FORS_TREE,FORS_PRF},hash::{trunc,short_block},sha256::compress_portable};
    const STATE:[u32;8]=[11, 37, 65535, 888,0x98765432,0xdeadbeef,0,278];
    fn bench(f:impl FnMut(), op:&str,n:usize,b:usize) {
        let t=Instant::now();
        (0..2048).for_each({let mut f=f;move |_| f()});
        println!("K,{op},{n},{b},{}",t.elapsed().as_nanos()/2048);
    }
    fn leaves<const N:usize>(b:usize) {
        let a=Adrs::new().with_tree(89).with_type(FORS_TREE).with_keypair(23);
        let mut out=[[0x8d;N];33]; let sk=[0x52;N]; let first=98761;
        fors_leaves(&STATE,&sk,a,first,&mut out[..b]);
        let mut want=[[0x8d;N];33];
        for (j,v) in want[..b].iter_mut().enumerate(){
            let idx=first+j as u32;
            let p=short_block(&a.with_type(FORS_PRF).with_keypair(23).with_word3(idx),&sk);
            let d=trunc::<N>(&compress_portable(&STATE,&p,0));
            *v=trunc(&compress_portable(&STATE,&short_block(&a.with_word3(idx),&d),0));
        }
        assert_eq!(out,want);
        bench(||fors_leaves(black_box(&STATE),&sk,a,first,black_box(&mut out[..b])),"leaves",N,b);
    }
    #[test] fn measure_leaves(){
        for b in (0..=17).chain([23,31,32,33]) {
            leaves::<16>(b); leaves::<24>(b); leaves::<32>(b);
        }
    }
}
