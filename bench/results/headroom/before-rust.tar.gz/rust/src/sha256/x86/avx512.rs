//! Sixteen independent SHA-256 chains. Keep message words transposed across
//! steps. Only the counter and the truncated digest change between steps.
use core::arch::x86_64::*;

#[target_feature(enable = "avx512f,avx512bw")]
pub(super) fn chains<const N: usize>(
    state: &[u32; 8],
    blocks: &mut [[u8; 64]],
    start: &[u32],
    end: &[u32],
) {
    debug_assert!(matches!(N, 16 | 24 | 32));
    let initial = state.map(|v| _mm512_set1_epi32(v as i32));
    let stride = _mm512_set_epi32(
        240, 224, 208, 192, 176, 160, 144, 128, 112, 96, 80, 64, 48, 32, 16, 0,
    );
    let swap = _mm512_broadcast_i32x4(_mm_set_epi32(
        0x0c0d0e0f, 0x08090a0b, 0x04050607, 0x00010203,
    ));
    for (group, batch) in blocks.chunks_mut(16).enumerate() {
        let offset = group * 16;
        // A short last batch has too few useful lanes on SHA-NI machines.
        if batch.len() < 8 && super::sha_ni::get() {
            // SAFETY: SHA-NI, SSSE3 and SSE4.1 are present.
            unsafe { super::chains::<N>(state, batch, &start[offset..], &end[offset..]) };
            continue;
        }
        let mask = (u16::MAX >> (16 - batch.len())) as __mmask16;
        let ptr = batch.as_mut_ptr().cast::<u8>();
        // SAFETY: each enabled lane addresses a distinct 64-byte block. For
        // the counters the caller checked that both slices cover all blocks.
        let mut counter =
            unsafe { _mm512_maskz_loadu_epi32(mask, start.as_ptr().add(offset).cast()) };
        let ends = unsafe { _mm512_maskz_loadu_epi32(mask, end.as_ptr().add(offset).cast()) };
        let mut active = _mm512_cmplt_epu32_mask(counter, ends) & mask;
        if active == 0 {
            continue;
        }
        let mut words: [__m512i; 16] = core::array::from_fn(|i| {
            let v = unsafe {
                _mm512_mask_i32gather_epi32::<4>(
                    _mm512_setzero_si512(),
                    active,
                    stride,
                    ptr.add(i * 4).cast(),
                )
            };
            _mm512_shuffle_epi8(v, swap)
        });
        let fixed4 = _mm512_and_si512(words[4], _mm512_set1_epi32(0xffff0000u32 as i32));
        let half = _mm512_set1_epi32(0xffff);
        // W0..W3 hold the unchanged prefix. The first four rounds depend only on it.
        let mut prefix = initial;
        for i in 0..4 {
            prefix = round(prefix, words[i], super::super::K[i]);
        }
        loop {
            words[4] = _mm512_or_si512(fixed4, _mm512_srli_epi32::<16>(counter));
            words[5] = _mm512_or_si512(
                _mm512_slli_epi32::<16>(counter),
                _mm512_and_si512(words[5], half),
            );
            let hash = compress(initial, prefix, words);
            let next = _mm512_add_epi32(counter, _mm512_set1_epi32(1));
            let finished = active & _mm512_cmpeq_epi32_mask(next, ends);
            if finished != 0 {
                // SAFETY: bytes 18..22 hold the counter and bytes 22..22+N
                // the digest. Scatter offsets stay inside enabled blocks.
                unsafe {
                    _mm512_mask_i32scatter_epi32::<4>(
                        ptr.add(18).cast(),
                        finished,
                        stride,
                        _mm512_shuffle_epi8(counter, swap),
                    );
                    for i in 0..N / 4 {
                        _mm512_mask_i32scatter_epi32::<4>(
                            ptr.add(22 + 4 * i).cast(),
                            finished,
                            stride,
                            _mm512_shuffle_epi8(hash[i], swap),
                        );
                    }
                }
                active &= !finished;
                if active == 0 {
                    break;
                }
            }
            // Digest byte zero starts halfway through W5. Preserve the
            // padding after its last half-word (at W9, W11 or W13).
            words[5] = _mm512_srli_epi32::<16>(hash[0]);
            for i in 1..N / 4 {
                words[5 + i] = _mm512_or_si512(
                    _mm512_slli_epi32::<16>(hash[i - 1]),
                    _mm512_srli_epi32::<16>(hash[i]),
                );
            }
            words[5 + N / 4] = _mm512_or_si512(
                _mm512_slli_epi32::<16>(hash[N / 4 - 1]),
                _mm512_and_si512(words[5 + N / 4], half),
            );
            counter = next;
        }
    }
}

#[inline]
#[target_feature(enable = "avx512f")]
fn round([a, b, c, d, e, f, g, h]: [__m512i; 8], w: __m512i, k: u32) -> [__m512i; 8] {
    let sum1 = _mm512_ternarylogic_epi32::<0x96>(
        _mm512_ror_epi32::<6>(e),
        _mm512_ror_epi32::<11>(e),
        _mm512_ror_epi32::<25>(e),
    );
    let ch = _mm512_ternarylogic_epi32::<0xca>(e, f, g);
    let t1 = _mm512_add_epi32(
        _mm512_add_epi32(h, sum1),
        _mm512_add_epi32(ch, _mm512_add_epi32(w, _mm512_set1_epi32(k as i32))),
    );
    let sum0 = _mm512_ternarylogic_epi32::<0x96>(
        _mm512_ror_epi32::<2>(a),
        _mm512_ror_epi32::<13>(a),
        _mm512_ror_epi32::<22>(a),
    );
    let maj = _mm512_ternarylogic_epi32::<0xe8>(a, b, c);
    [
        _mm512_add_epi32(t1, _mm512_add_epi32(sum0, maj)),
        a,
        b,
        c,
        _mm512_add_epi32(d, t1),
        e,
        f,
        g,
    ]
}

#[inline]
#[target_feature(enable = "avx512f")]
fn compress(initial: [__m512i; 8], mut state: [__m512i; 8], mut w: [__m512i; 16]) -> [__m512i; 8] {
    // Constant indices expose the rolling schedule to register allocation.
    macro_rules! step {
        ($i:expr) => {{
            const I: usize = $i;
            if I >= 16 {
                let x = w[(I + 1) % 16];
                let y = w[(I + 14) % 16];
                let s0 = _mm512_ternarylogic_epi32::<0x96>(
                    _mm512_ror_epi32::<7>(x),
                    _mm512_ror_epi32::<18>(x),
                    _mm512_srli_epi32::<3>(x),
                );
                let s1 = _mm512_ternarylogic_epi32::<0x96>(
                    _mm512_ror_epi32::<17>(y),
                    _mm512_ror_epi32::<19>(y),
                    _mm512_srli_epi32::<10>(y),
                );
                w[I % 16] = _mm512_add_epi32(
                    _mm512_add_epi32(w[I % 16], w[(I + 9) % 16]),
                    _mm512_add_epi32(s0, s1),
                );
            }
            state = round(state, w[I % 16], super::super::K[I]);
        }};
    }
    macro_rules! four {
        ($i:expr) => {
            step!($i);
            step!($i + 1);
            step!($i + 2);
            step!($i + 3);
        };
    }
    four!(4);
    four!(8);
    four!(12);
    four!(16);
    four!(20);
    four!(24);
    four!(28);
    four!(32);
    four!(36);
    four!(40);
    four!(44);
    four!(48);
    four!(52);
    four!(56);
    four!(60);
    core::array::from_fn(|i| _mm512_add_epi32(initial[i], state[i]))
}
