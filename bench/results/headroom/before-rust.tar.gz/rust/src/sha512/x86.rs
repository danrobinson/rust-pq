//! Compute eight independent SHA-512 parent hashes in a FORS tree level.
use crate::address::Adrs;
use core::arch::x86_64::*;

pub(crate) fn parents<const N: usize>(
    state: &[u64; 8],
    adrs: Adrs,
    first: u32,
    values: &mut [[u8; N]],
    count: usize,
) -> usize {
    if !matches!(N, 24 | 32) || count < 8 || !crate::sha256::x86::avx512_available() {
        return 0;
    }
    // SAFETY: the OS and processor support the required AVX-512 instructions.
    unsafe { hash_groups(state, adrs, first, values, count) }
}

#[target_feature(enable = "avx512f,avx512bw")]
fn hash_groups<const N: usize>(
    state: &[u64; 8],
    adrs: Adrs,
    first: u32,
    values: &mut [[u8; N]],
    count: usize,
) -> usize {
    let initial = state.map(|x| _mm512_set1_epi64(x as i64));
    let end = count / 8 * 8;
    for j in (0..end).step_by(8) {
        // The seeded prefix has consumed 128 bytes. Each parent takes one
        // further padded block containing ADRSc || left || right.
        let mut blocks = [[0u8; 128]; 8];
        for (lane, block) in blocks.iter_mut().enumerate() {
            let i = j + lane;
            block[..22].copy_from_slice(&adrs.with_word3(first + i as u32).compress());
            block[22..22 + N].copy_from_slice(&values[2 * i]);
            block[22 + N..22 + 2 * N].copy_from_slice(&values[2 * i + 1]);
            block[22 + 2 * N] = 0x80;
            block[120..].copy_from_slice(&(((150 + 2 * N) * 8) as u64).to_be_bytes());
        }
        let mut w: [__m512i; 16] = core::array::from_fn(|i| {
            let lanes: [u64; 8] = core::array::from_fn(|l| {
                u64::from_be_bytes(blocks[l][8 * i..8 * i + 8].try_into().unwrap())
            });
            // SAFETY: a vector contains eight native-endian u64 lanes.
            unsafe { core::mem::transmute(lanes) }
        });
        let mut s = initial;
        macro_rules! step {
            ($i:expr) => {{
                const I: usize = $i;
                if I >= 16 {
                    let x = w[(I + 1) % 16];
                    let y = w[(I + 14) % 16];
                    let s0 = _mm512_ternarylogic_epi64::<0x96>(
                        _mm512_ror_epi64::<1>(x),
                        _mm512_ror_epi64::<8>(x),
                        _mm512_srli_epi64::<7>(x),
                    );
                    let s1 = _mm512_ternarylogic_epi64::<0x96>(
                        _mm512_ror_epi64::<19>(y),
                        _mm512_ror_epi64::<61>(y),
                        _mm512_srli_epi64::<6>(y),
                    );
                    w[I % 16] = _mm512_add_epi64(
                        _mm512_add_epi64(w[I % 16], w[(I + 9) % 16]),
                        _mm512_add_epi64(s0, s1),
                    );
                }
                let [a, b, c, d, e, f, g, h] = s;
                let sum1 = _mm512_ternarylogic_epi64::<0x96>(
                    _mm512_ror_epi64::<14>(e),
                    _mm512_ror_epi64::<18>(e),
                    _mm512_ror_epi64::<41>(e),
                );
                let ch = _mm512_ternarylogic_epi64::<0xca>(e, f, g);
                let wk = _mm512_add_epi64(w[I % 16], _mm512_set1_epi64(super::K[I] as i64));
                let t1 = _mm512_add_epi64(_mm512_add_epi64(h, sum1), _mm512_add_epi64(ch, wk));
                let sum0 = _mm512_ternarylogic_epi64::<0x96>(
                    _mm512_ror_epi64::<28>(a),
                    _mm512_ror_epi64::<34>(a),
                    _mm512_ror_epi64::<39>(a),
                );
                let maj = _mm512_ternarylogic_epi64::<0xe8>(a, b, c);
                s = [
                    _mm512_add_epi64(t1, _mm512_add_epi64(sum0, maj)),
                    a,
                    b,
                    c,
                    _mm512_add_epi64(d, t1),
                    e,
                    f,
                    g,
                ];
            }};
        }
        macro_rules! four {
            ($i:expr) => {
                step!($i);
                step!($i + 1);
                step!($i + 2);
                step!($i + 3);
            };
        }
        four!(0);
        four!(4);
        four!(8);
        four!(12);
        four!(16);
        four!(20);
        four!(24);
        four!(28);
        four!(32);
        four!(36);
        four!(40);
        four!(44);
        four!(48);
        four!(52);
        four!(56);
        four!(60);
        four!(64);
        four!(68);
        four!(72);
        four!(76);
        for i in 0..N / 8 {
            // SAFETY: all bit patterns are valid for the eight u64 words.
            let lanes: [u64; 8] =
                unsafe { core::mem::transmute(_mm512_add_epi64(initial[i], s[i])) };
            for (lane, x) in lanes.into_iter().enumerate() {
                values[j + lane][8 * i..8 * i + 8].copy_from_slice(&x.to_be_bytes());
            }
        }
    }
    end
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::hash::{seed_ctx, thash_pair};

    fn check<const N: usize>() {
        let seed = seed_ctx(&core::array::from_fn::<_, N, _>(|i| (i * 13) as u8));
        let adrs = Adrs::new()
            .with_layer(7)
            .with_tree(0x1122334455667788)
            .with_type(crate::address::FORS_TREE)
            .with_keypair(257)
            .with_word2(8);
        for count in 0..=33 {
            let mut values: [[u8; N]; 66] =
                core::array::from_fn(|i| core::array::from_fn(|j| (i * 31 + j * 11) as u8));
            let mut expected = values;
            let processed = parents(&seed.state512, adrs, 65532, &mut values[..2 * count], count);
            assert_eq!(
                processed,
                if crate::sha256::x86::avx512_available() {
                    count / 8 * 8
                } else {
                    0
                }
            );
            for i in 0..processed {
                expected[i] = thash_pair(
                    &seed,
                    &adrs.with_word3(65532 + i as u32),
                    &expected[2 * i],
                    &expected[2 * i + 1],
                );
            }
            assert_eq!(values, expected);
        }
    }

    #[test]
    fn in_place_fors_parent_batches_match_scalar() {
        check::<24>();
        check::<32>();
    }
}
